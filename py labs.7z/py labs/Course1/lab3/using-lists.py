users = []

users.append('kevin')
users.append('bob')
users.append('alice')

del users[1]

rev_users = list(reversed(users))

users.insert(1, "melody")

users += ['andy', 'wanda', 'jim']

center_users = users[2:4]

#print(center_users)