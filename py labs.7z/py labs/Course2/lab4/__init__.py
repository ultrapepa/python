__all__ = ["random_words"]

from .generator import *
